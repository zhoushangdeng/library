book_name: 前端开发之路
imgPath: null
writer: shangdeng
sort_name: 软件工程
price: null
pub_company: pub_company
pub_date: 2022-04-03T06:19:38.000Z
total_num: 100
current_num: 1
buy_date: 2022-04-03T06:19:46.000Z
brief: 23123

book_id: 1
        student_code: 211
        borrow_date: 2018-12-10T13:38:39.000Z
        return_date: 2018-12-27T13:38:56.000Z